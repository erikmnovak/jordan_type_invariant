"""Independent component-map oracle for the two saved H0 graph presentations."""
from pathlib import Path
import json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

root = Path('/home/eriknovak/Documents/projects/jordan_type_invariant')
scratch = Path('/tmp/jordan-suite-jd5bjqdx')
answers = {}
for line in (scratch / 'validation.txt').read_text().splitlines():
    parts = line.split()
    if parts[0] in ['jordan', 'streaming', 'filtered', 'blocks']:
        answers[tuple(parts[:2])] = list(map(int, parts[2:]))
assert answers['blocks', 'fork_shared'] == [2, 1]
assert answers['blocks', 'fork_independent'] == [0, 2]
assert answers['blocks', 'fork_shared_single'] == answers['blocks', 'fork_independent_single'] == [1, 1]
assert answers['blocks', 'diamond_cancellation'] == [0, 2, 0]
records = []
for name in ['tumour_foxp3', 'tumour_cd8']:
    lines = (root / f'benchmarks/data/{name}.scc').read_text().splitlines()
    relations, generators, _ = map(int, lines[2].split())
    edge_grades = np.array([list(map(float, line.split(';')[0].split())) for line in lines[3:3+relations]])
    edges = np.array([list(map(int, line.split(';')[1].split())) for line in lines[3:3+relations]])
    births = np.array([list(map(float, line.split(';')[0].split())) for line in lines[3+relations:]])
    text = (root / f'benchmarks/data/{name}.slices').read_text().splitlines()
    points = np.array([list(map(float, text[i].split())) for i in range(3, len(text), 2)])
    offset = (points.max(axis=0) - points.min(axis=0)) / 16
    cache = {}

    def components(grade):
        key = tuple(grade)
        if key not in cache:
            active = np.flatnonzero(np.all(births <= grade, axis=1))
            lookup = np.full(generators, -1, dtype=np.int64)
            lookup[active] = np.arange(len(active))
            selected = edges[np.all(edge_grades <= grade, axis=1)]
            assert np.all(lookup[selected] >= 0)
            graph = coo_matrix((np.ones(len(selected)), (lookup[selected[:,0]], lookup[selected[:,1]])),
                               shape=(len(active), len(active))).tocsr()
            count, labels = connected_components(graph, directed=False)
            full_labels = np.full(generators, -1, dtype=np.int64)
            full_labels[active] = labels
            cache[key] = (active, full_labels, int(count))
        return cache[key]

    def ranks(displacement):
        result = []
        for power in range(len(points)):
            rank = 0
            for start in range(len(points) - power):
                active, _, _ = components(points[start])
                _, target_labels, _ = components(points[start + power] + displacement)
                assert np.all(target_labels[active] >= 0)
                rank += len(np.unique(target_labels[active]))
            result.append(rank)
        return result + [0]

    jordan = ranks(np.zeros(2))
    filtered = ranks(offset)[:-1]
    assert jordan == answers['jordan', name] == answers['streaming', name]
    assert filtered == answers['filtered', name]
    records.append({'name': name, 'jordan_power_ranks': jordan, 'filtered_ranks': filtered,
                    'target_offset': offset.tolist(), 'component_computations': len(cache)})
(scratch / 'graph-validation.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
