#define benchmark historical
#include "before/benchmarks/workloads.hpp"
#undef benchmark
#include "/home/eriknovak/Documents/projects/jordan_type_invariant/benchmarks/workloads.hpp"
#include <iostream>

using namespace jordan::f2;
void require(bool value, const char* message) {
  if (!value) throw std::runtime_error(message);
}
void same_input(const benchmark::Workload& now, const historical::Workload& old) {
  require(now.presentation.num_parameters == old.presentation.num_parameters &&
          now.presentation.generator_grades == old.presentation.generator_grades &&
          now.presentation.relation_grades == old.presentation.relation_grades &&
          now.presentation.relations == old.presentation.relations && now.slices == old.slices &&
          now.query_period == old.query_period && now.seed == old.seed, "Original recipe changed");
  for (std::size_t i = 0; i < now.query_period; ++i)
    require(benchmark::shift(now, i) == historical::shift(old, i), "Original translations changed");
}
void known_blocks(std::string_view name, std::vector<std::size_t> expected, std::uint32_t seed = 61801) {
  auto work = benchmark::scaling_workload(name, seed);
  Engine engine(work.presentation);
  SlicePattern pattern(work.presentation.num_parameters, work.slices);
  for (std::size_t i = 0; i < work.query_period; ++i)
    for (auto method : {JordanMethod::rank_blocks, JordanMethod::streaming}) {
      const auto result = engine.jordan_type(pattern, benchmark::shift(work, i), method);
      require(result.block_multiplicities == expected, "Analytic block counts disagree");
    }
  std::cout << "analytic " << name << ' ' << seed << '\n';
}
void row(const char* kind, const std::string& name, const std::vector<std::size_t>& values) {
  std::cout << kind << ' ' << name;
  for (auto value : values) std::cout << ' ' << value;
  std::cout << '\n';
}
int main(int argc, char** argv) {
  try {
    for (auto name : historical::method_names) same_input(benchmark::method_workload(name), historical::method_workload(name));
    for (auto name : historical::query_names) same_input(benchmark::query_workload(name), historical::query_workload(name));
    std::cout << "original_recipes 14\n";
    for (auto size : {2048, 16384, 131072}) {
      std::vector<std::size_t> blocks(8); blocks[0] = 2; blocks[1] = 7;
      known_blocks("thin_" + std::to_string(size), blocks);
    }
    for (auto size : {16, 256, 1024}) {
      std::vector<std::size_t> blocks(16); blocks.back() = size;
      known_blocks("stalk_" + std::to_string(size), blocks);
    }
    for (auto size : {512, 1024}) {
      std::vector<std::size_t> blocks(16); blocks.back() = size / 4;
      for (int r = 0; r < 3 * size / 4; ++r) ++blocks[r % 15];
      for (auto seed : {61801u, 61802u}) {
        known_blocks("basis_sparse_" + std::to_string(size), blocks, seed);
        known_blocks("basis_dense_" + std::to_string(size), blocks, seed);
        if (size == 512) known_blocks("redundant_512", blocks, seed);
      }
    }
    std::vector<std::size_t> boxes(8);
    for (int g = 0; g < 256; ++g) ++boxes[std::min(g % 4 + 2 + g % 5, 8) - g % 4 - 1];
    for (auto name : {"boxes_1d", "boxes_2d", "boxes_3d"}) known_blocks(name, boxes);
    for (auto width : {8, 9}) {
      std::vector<std::size_t> blocks(32);
      if (width % 2) { blocks[0] = 32 * 32 * (width - 1); blocks.back() = 32; }
      else { blocks[1] = 32 * 31; blocks[0] = 32 * 32 * width - 2 * blocks[1]; }
      known_blocks(width == 8 ? "even_width_8" : "odd_width_9", blocks);
    }
    SlicePattern point(2, {{{0, 0}}, {}});
    auto left = benchmark::fixed_workload(*benchmark::file_case("fork_shared"));
    auto right = benchmark::fixed_workload(*benchmark::file_case("fork_independent"));
    Engine a(left.presentation), b(right.presentation);
    int comparisons = 0;
    for (int x = -1; x <= 1; ++x) for (int y = -1; y <= 1; ++y)
      for (int u = x; u <= 1; ++u) for (int v = y; v <= 1; ++v) {
        require(a.filtered_rank(point, 0, {double(x), double(y)}, {double(u), double(v)}) ==
                b.filtered_rank(point, 0, {double(x), double(y)}, {double(u), double(v)}), "Fork classical ranks differ");
        ++comparisons;
      }
    std::cout << "fork_classical_pairs " << comparisons << '\n';
    for (auto name : {"fork_shared", "fork_independent", "fork_shared_single", "fork_independent_single", "diamond_cancellation"}) {
      auto work = benchmark::fixed_workload(*benchmark::file_case(name));
      Engine engine(work.presentation); SlicePattern pattern(2, work.slices);
      row("blocks", name, engine.jordan_type(pattern, {0, 0}).block_multiplicities);
    }
    for (auto name : {"tumour_foxp3", "tumour_cd8"}) {
      auto work = benchmark::fixed_workload(*benchmark::file_case(name));
      Engine engine(work.presentation); SlicePattern pattern(2, work.slices);
      row("jordan", name, engine.jordan_type(pattern, {0, 0}, JordanMethod::rank_blocks).power_ranks);
      row("streaming", name, engine.jordan_type(pattern, {0, 0}, JordanMethod::streaming).power_ranks);
      row("filtered", name, engine.filtered_ranks(pattern, {0, 0}, benchmark::rank_offset(work)));
    }
    if (argc > 1) {
      std::ifstream probes(argv[1]); std::string name; double x, y; std::size_t dimension; int checked = 0;
      while (probes >> name >> x >> y >> dimension) {
        auto work = benchmark::fixed_workload(*benchmark::file_case(name)); Engine engine(work.presentation);
        require(engine.filtered_rank(point, 0, {x, y}, {x, y}) == dimension, "Graph component count differs");
        ++checked;
      }
      require(checked == 24, "Expected 24 independent graph probes");
      std::cout << "graph_probes " << checked << '\n';
    }
  } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
