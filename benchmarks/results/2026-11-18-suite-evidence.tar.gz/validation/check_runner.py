from pathlib import Path
import csv, json, subprocess

root = Path('/home/eriknovak/Documents/projects/jordan_type_invariant')
scratch = Path('/tmp/jordan-suite-jd5bjqdx')
stub = scratch / 'runner_probe.py'
stub.write_text('''#!/usr/bin/python3
import resource, sys, time
if "--list" in sys.argv:
    print("workload,presentation,slice_file,seed")
    for name in ["valid", "timeout", "incomplete", "mismatch", "allocation"]: print(name + ",,,")
    raise SystemExit(0)
name = sys.argv[1]
assert resource.getrlimit(resource.RLIMIT_AS) == (64 * 1024**2, 64 * 1024**2)
if name == "timeout": time.sleep(3)
if name == "allocation":
    try: data = bytearray(128 * 1024**2)
    except MemoryError:
        print("std::bad_alloc", file=sys.stderr)
        raise SystemExit(1)
    raise RuntimeError("Memory limit did not apply")
print("workload,checksum")
if name == "incomplete": print(name)
else: print(name + "," + ("2" if name == "mismatch" and "reset" in sys.argv else "1"))
''')
stub.chmod(0o755)
output = scratch / 'runner-probe.csv'
command = ['python3', str(root/'benchmarks/run_suite.py'), str(stub), str(output),
           '--repeats', '1', '--timeout', '0.2', '--memory-mib', '64']
result = subprocess.run(command, capture_output=True, text=True)
assert result.returncode == 1, result.stderr
rows = list(csv.DictReader(output.with_suffix('.runs.csv').open()))
expected = {'valid': ['ok','ok'], 'timeout': ['timeout','timeout'], 'incomplete': ['invalid_output','invalid_output'],
            'mismatch': ['ok','result_mismatch'], 'allocation': ['memory_limit','memory_limit']}
for name, statuses in expected.items():
    assert [r['status'] for r in rows if r['workload'] == name] == statuses
assert len(list(csv.DictReader(output.open()))) == 3
before = output.read_bytes()
refused = subprocess.run(command, capture_output=True, text=True)
assert refused.returncode != 0 and 'already exist' in refused.stderr and output.read_bytes() == before
(scratch/'runner-checks.json').write_text(json.dumps({'statuses':expected,'existing_output_preserved':True,
                                                    'virtual_memory_limit_enforced':True},indent=2)+'\n')
print('Runner success, timeout, memory limit, malformed output, mismatch and overwrite checks passed')
