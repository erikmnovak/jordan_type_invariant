from pathlib import Path
import csv,json,hashlib,urllib.request
import numpy as np
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
root=Path('/tmp/jordan-suite-jd5bjqdx');output=root/'candidates';output.mkdir(exist_ok=True)
commit='b86114a135b3e45dac37edf7219b0ebad9517163'
url=f'https://raw.githubusercontent.com/MultiparameterTDAHistology/SpatialPatterningOfImmuneCells/{commit}/LargeHypoxicRegion2.csv'
raw=root/'LargeHypoxicRegion2.csv'
with urllib.request.urlopen(url,timeout=30) as response:raw.write_bytes(response.read())
rows=list(csv.DictReader(raw.open()));records=[]
for celltype,stem in [('FoxP3','tumour_foxp3_h0'),('CD8','tumour_cd8_h0')]:
    points=np.asarray([(float(r['x']),float(r['y'])) for r in rows if r['Celltype']==celltype],dtype=np.float64)
    tree=cKDTree(points);distances,_=tree.query(points,k=9)
    weights=np.sqrt(np.mean(distances[:,1:]**2,axis=1))
    radius=float(np.quantile(distances[:,8],0.95))
    edges=tree.query_pairs(radius,output_type='ndarray')
    edges=edges[np.lexsort((edges[:,1],edges[:,0]))]
    lengths=np.linalg.norm(points[edges[:,0]]-points[edges[:,1]],axis=1)
    keep=lengths<=radius;edges=edges[keep];lengths=lengths[keep]
    edge_weights=np.maximum(weights[edges[:,0]],weights[edges[:,1]])
    path=output/(stem+'.scc')
    with path.open('w') as file:
        file.write('scc2020\n2\n'+str(len(edges))+' '+str(len(points))+' 0\n')
        for (a,b),length,weight in zip(edges,lengths,edge_weights):file.write(f'{length:.17g} {weight:.17g} ; {a} {b}\n')
        for weight in weights:file.write(f'0 {weight:.17g} ;\n')
    # Component counts supply an independent H0 oracle at fixed parameter values.
    probes=[]
    for distance_quantile in [0.1,0.3,0.5,0.7]:
        for density_quantile in [0.25,0.5,0.75]:
            distance=float(np.quantile(lengths,distance_quantile));density=float(np.quantile(weights,density_quantile))
            active=np.flatnonzero(weights<=density);lookup=np.full(len(points),-1,dtype=np.int64);lookup[active]=np.arange(len(active))
            selected=edges[(lengths<=distance)&(edge_weights<=density)]
            adjacency=coo_matrix((np.ones(len(selected)),(lookup[selected[:,0]],lookup[selected[:,1]])),shape=(len(active),len(active))).tocsr()
            components=int(connected_components(adjacency,directed=False,return_labels=False))
            probes.append({'grade':[distance,density],'dimension':components})
    record={'name':stem,'source_url':url,'source_commit':commit,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'cell_type':celltype,'generators':len(points),'relations':len(edges),'parameters':2,'homology_degree':0,'minimal':False,'density':'root mean squared distance to the eight nearest other points','edge_radius_cutoff':radius,'cutoff_rule':'95th percentile of the eighth-neighbour distance','filtration':'vertices at (0, codensity); edges at (Euclidean length, max endpoint codensity); edges beyond cutoff omitted','coordinate_units':'native published coordinate units','sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'probes':probes}
    records.append(record)
    print(stem,'vertices',len(points),'edges',len(edges),'radius',radius,'dimension range',min(x['dimension'] for x in probes),max(x['dimension'] for x in probes),flush=True)
(root/'cell-sources.json').write_text(json.dumps(records,indent=2)+'\n')
