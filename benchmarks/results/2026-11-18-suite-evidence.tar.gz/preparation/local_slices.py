from pathlib import Path
import subprocess,json
import numpy as np
root=Path('/home/eriknovak/Documents/projects/jordan_type_invariant');data=root/'benchmarks/data';exe=Path('/tmp/jordan-type-build/jordan_type')
def load(path):
    lines=[line.split('#')[0].strip() for line in path.read_text().splitlines() if line.split('#')[0].strip()]
    r,g,*_=map(int,lines[2].split())
    relations=[tuple(map(float,line.split(';')[0].split())) for line in lines[3:3+r]]
    generators=[tuple(map(float,line.split(';')[0].split())) for line in lines[3+r:3+r+g]]
    return generators,relations
records=[]
for name in ['multicover_small','multicover_large','dragon']:
    generators,relations=load(data/(name+'.scc'))
    for index in [len(generators)//2,len(generators)//4,3*len(generators)//4,0]:
        start=generators[index]
        events=sorted({p[0] for p in generators+relations if p[1]<=start[1] and p[0]>start[0]})
        if len(events)<2:continue
        endpoint=events[1]
        for n in [2,8,32] if name=='multicover_large' else [8]:
            xs=np.linspace(start[0],endpoint,n)
            if len(np.unique(xs))!=n:raise RuntimeError('Unrepresentable slice spacing')
            path=data/(name+f'_local_{n}.slices')
            with path.open('w') as f:
                f.write(f'jordan-slices-v1\n2 {n}\n')
                for x in xs:f.write(f'1\n{x:.17g} {start[1]:.17g}\n')
        check=data/(name+'_local_8.slices')
        run=subprocess.run([str(exe),'type',str(data/(name+'.scc')),str(check),'--method','streaming'],capture_output=True,text=True,check=True,timeout=30)
        ranks=list(map(int,run.stdout.splitlines()[0].split(':')[1].split()))
        if ranks[1]>0:
            records.append({'name':name,'generator_index':index,'start':start,'end':[endpoint,start[1]],'ranks_8':ranks,'rule':'Hold the second coordinate at a generator birth and span to the second subsequent active critical first-coordinate value.'})
            print(name,'local ranks',ranks,flush=True);break
    else:raise RuntimeError('Could not find a nontrivial local window: '+name)
(root/'benchmarks/data/fork_single.slices').write_text('jordan-slices-v1\n2 2\n1\n0 0\n1\n1 0\n')
(root/'benchmarks/data/single_point.slices').write_text('jordan-slices-v1\n2 2\n1\n0 0\n0\n')
path=data/'sources.json';metadata=json.loads(path.read_text());metadata['local_sampling']=records;path.write_text(json.dumps(metadata,indent=2)+'\n')
