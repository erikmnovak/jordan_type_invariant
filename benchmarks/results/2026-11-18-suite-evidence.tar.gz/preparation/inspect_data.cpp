#include <jordan/io.hpp>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace jordan::f2;
int main(int argc,char** argv) {
  if(argc<2)return 1;
  try {
    auto input=read_presentation_file(argv[1]);
    std::vector<std::vector<double>> axes(input.num_parameters);
    for(const auto* grades:{&input.generator_grades,&input.relation_grades})
      for(const auto& grade:*grades)for(std::size_t k=0;k<axes.size();++k)axes[k].push_back(grade[k]);
    for(auto& axis:axes){std::sort(axis.begin(),axis.end());axis.erase(std::unique(axis.begin(),axis.end()),axis.end());}
    std::cout<<std::setprecision(17)<<"COUNTS "<<input.generator_grades.size()<<' '<<input.relations.size()<<'\n';
    for(const auto& axis:axes)std::cout<<"AXIS "<<axis.size()<<' '<<axis.front()<<' '<<axis.back()<<'\n';
    std::vector<std::vector<Grade>> layers;
    for(double fraction:{0.1,0.3,0.5,0.7}){
      Grade point;
      for(const auto& axis:axes)point.push_back(axis[std::size_t(fraction*double(axis.size()-1))]);
      if(layers.empty()||point!=layers.back().front())layers.push_back({point});
    }
    if(layers.size()<2)throw std::runtime_error("Not enough distinct critical-coordinate points");
    if(argc>2){std::ofstream out(argv[2]);out<<std::setprecision(17)<<"jordan-slices-v1\n"<<input.num_parameters<<' '<<layers.size()<<'\n';for(const auto& layer:layers){out<<"1\n";for(std::size_t k=0;k<layer[0].size();++k)out<<(k?" ":"")<<layer[0][k];out<<'\n';}}
    Engine engine(input);SlicePattern pattern(input.num_parameters,layers);
    auto start=std::chrono::steady_clock::now();
    const auto result=engine.jordan_type(pattern,Grade(input.num_parameters,0),JordanMethod::streaming);
    std::cout<<"RANKS";for(auto rank:result.power_ranks)std::cout<<' '<<rank;
    std::cout<<"\nMS "<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<'\n';
  } catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
