#pragma once

// Named input recipes shared by the two benchmark programs. A recipe creates
// one presentation and pattern. Translations are computed from their index,
// so increasing the query count does not allocate a list of queries.
#include <jordan/io.hpp>

#include <algorithm>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <functional>
#include <fstream>
#include <iostream>
#include <optional>
#include <random>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace benchmark {
using namespace jordan::f2;

enum class CachePolicy { reuse, reset };

struct Options {
  std::string workload = "all";
  CachePolicy cache = CachePolicy::reuse;
  std::optional<std::size_t> queries;
  std::string presentation_file;
  std::string slices_file;
  std::string step;
  std::string answers_file;
  bool help = false;
};

inline Options options(int argc, char** argv) {
  Options result;
  int i = 1;
  if (i < argc && !std::string_view(argv[i]).starts_with("--")) result.workload = argv[i++];
  std::set<std::string> seen;
  for (; i < argc; ++i) {
    const std::string option(argv[i]);
    if (option == "--help") { result.help = true; return result; }
    if (!seen.insert(option).second) throw std::invalid_argument("Repeated option: " + option);
    if (i + 1 == argc) throw std::invalid_argument("Missing value for " + option);
    const std::string value(argv[++i]);
    if (value.empty()) throw std::invalid_argument("Empty value for " + option);
    if (option == "--cache") {
      if (value == "reuse") result.cache = CachePolicy::reuse;
      else if (value == "reset") result.cache = CachePolicy::reset;
      else throw std::invalid_argument("--cache must be reuse or reset");
    } else if (option == "--queries") {
      std::size_t count = 0;
      const auto [end, error] = std::from_chars(value.data(), value.data() + value.size(), count);
      if (error != std::errc{} || end != value.data() + value.size() || count == 0) {
        throw std::invalid_argument("--queries requires a positive integer");
      }
      result.queries = count;
    } else if (option == "--presentation") result.presentation_file = value;
    else if (option == "--slices") result.slices_file = value;
    else if (option == "--step") result.step = value;
    else if (option == "--answers") result.answers_file = value;
    else throw std::invalid_argument("Unknown option: " + option);
  }
  if (result.workload == "file") {
    if (result.presentation_file.empty() || result.slices_file.empty()) {
      throw std::invalid_argument("The file workload requires --presentation and --slices");
    }
    if (!result.step.empty() && !result.queries) throw std::invalid_argument("--step requires --queries");
  } else if (!result.presentation_file.empty() || !result.slices_file.empty() || !result.step.empty()) {
    throw std::invalid_argument("Input paths and --step require the file workload");
  }
  return result;
}

inline const char* cache_name(CachePolicy policy) {
  return policy == CachePolicy::reuse ? "reuse" : "reset";
}

inline void before_query(Engine& engine, CachePolicy policy) {
  if (policy == CachePolicy::reset) engine.clear_cache();
}

inline std::ofstream answer_file(const Options& settings) {
  if (settings.answers_file.empty()) return {};
  for (const auto& input : {settings.presentation_file, settings.slices_file}) {
    if (!input.empty() && std::filesystem::exists(input) && std::filesystem::exists(settings.answers_file) &&
        std::filesystem::equivalent(input, settings.answers_file)) {
      throw std::invalid_argument("The answer file must differ from the input files");
    }
  }
  std::ofstream output(settings.answers_file);
  if (!output) throw std::runtime_error("Cannot open answer file: " + settings.answers_file);
  return output;
}

struct Workload {
  std::string name;
  Presentation presentation;
  std::vector<std::vector<Grade>> slices;
  std::size_t query_period;
  // The same index must produce the same translation on every pass.
  std::function<Grade(std::size_t)> translation;
  std::optional<std::uint32_t> seed;
};

inline std::size_t query_count(const Workload& workload, const Options& settings) {
  return settings.queries.value_or(workload.query_period);
}

inline Grade shift(const Workload& workload, std::size_t query) {
  return workload.translation(query % workload.query_period);
}

inline Presentation free_module(std::size_t generators, std::size_t parameters) {
  return {parameters, std::vector<Grade>(generators, Grade(parameters, 0)), {}, {}};
}

// Each relation uses a fixed number of draws, then cancels duplicates over F2.
// Its grade is no earlier than the grades of the generators it uses.
inline Presentation mixed_module(std::size_t generators, std::size_t relations,
                                  std::size_t entries, std::uint32_t seed) {
  std::mt19937 random(seed);
  Presentation result;
  result.num_parameters = 2;
  for (std::size_t g = 0; g < generators; ++g) {
    result.generator_grades.push_back({double(random() % 12), double(random() % 12)});
  }
  for (std::size_t r = 0; r < relations; ++r) {
    Grade grade(2, 0);
    Column raw;
    for (std::size_t j = 0; j < entries; ++j) {
      const auto g = static_cast<Index>(random() % generators);
      raw.push_back(g);
      for (std::size_t axis = 0; axis < 2; ++axis) {
        grade[axis] = std::max(grade[axis], result.generator_grades[g][axis]);
      }
    }
    std::sort(raw.begin(), raw.end());
    Column column;
    for (std::size_t j = 0; j < raw.size();) {
      std::size_t end = j + 1;
      while (end < raw.size() && raw[end] == raw[j]) ++end;
      if ((end - j) % 2) column.push_back(raw[j]);
      j = end;
    }
    for (auto& value : grade) value += double(random() % 4);
    result.relation_grades.push_back(std::move(grade));
    result.relations.push_back(std::move(column));
  }
  return result;
}

inline std::vector<std::vector<Grade>> chain(std::size_t length, std::size_t parameters) {
  std::vector<std::vector<Grade>> slices;
  for (std::size_t i = 0; i < length; ++i) slices.push_back({Grade(parameters, double(i))});
  return slices;
}

inline std::vector<std::vector<Grade>> wide_chain(std::size_t length, std::size_t width) {
  std::vector<std::vector<Grade>> slices(length);
  for (std::size_t l = 0; l < length; ++l) {
    for (std::size_t j = 0; j < width; ++j) {
      slices[l].push_back({double(4 * l + j), double(4 * l + width - 1 - j)});
    }
  }
  return slices;
}

inline std::vector<std::vector<Grade>> small_grid() {
  return {{{0, 0}}, {{1, 0}, {0, 1}}, {{2, 0}, {1, 1}, {0, 2}},
          {{2, 1}, {1, 2}}, {{2, 2}}};
}

inline Grade zero_shift(std::size_t) { return {0, 0}; }
inline constexpr std::uint32_t grid_seed = 20261109;

inline const std::vector<std::string_view> method_names{
  "free_chain_8", "free_chain_32", "free_chain_128", "free_chain_256",
  "short_grid", "odd_width_3", "even_width_2", "mixed_chain", "dense_relations"};

inline const std::vector<std::string_view> query_names{
  "integer_grid", "fractional_grid", "dense_region", "distinct_regions", "free_chain"};

inline Workload method_workload(std::string_view name) {
  // Constant modules isolate how the query algorithms scale with slice length.
  for (std::size_t length : {8, 32, 128, 256}) {
    if (name == "free_chain_" + std::to_string(length)) {
      return {std::string(name), free_module(64, 2), chain(length, 2), 1, zero_shift, {}};
    }
  }
  if (name == "short_grid") {
    return {std::string(name), mixed_module(256, 320, 4, grid_seed), small_grid(), 12,
      [](std::size_t i) -> Grade { return {double(5 + i / 4), double(5 + i % 4)}; }, grid_seed};
  }
  // Odd width retains long paths; even width makes two-step paths cancel.
  if (name == "odd_width_3" || name == "even_width_2") {
    const auto length = name == "odd_width_3" ? 32 : 64;
    const auto width = name == "odd_width_3" ? 3 : 2;
    return {std::string(name), free_module(32, 2), wide_chain(length, width), 1, zero_shift, {}};
  }
  if (name == "mixed_chain") {
    constexpr std::uint32_t seed = 44001;
    return {std::string(name), mixed_module(128, 96, 4, seed), chain(64, 2), 4,
      [](std::size_t i) -> Grade { return {double(i % 2), double(i / 2)}; }, seed};
  }
  if (name == "dense_relations") {
    constexpr std::uint32_t seed = 44002;
    return {std::string(name), mixed_module(128, 112, 32, seed), chain(64, 2), 1, zero_shift, seed};
  }
  throw std::invalid_argument("Unknown method workload: " + std::string(name));
}

inline Workload query_workload(std::string_view name) {
  if (name == "integer_grid" || name == "fractional_grid") {
    const bool fractional = name == "fractional_grid";
    return {std::string(name), mixed_module(256, 320, 4, grid_seed), small_grid(), 108,
      [fractional](std::size_t i) -> Grade {
        const double offset = fractional ? (i / 36) / 4.0 : 0;
        return {4 + double((i % 36) / 6) + offset, 4 + double(i % 6) + offset};
      }, grid_seed};
  }
  if (name == "dense_region") {
    // Every sampled point shares one nontrivial relation space.
    auto input = free_module(128, 2);
    constexpr std::uint32_t seed = 20261116;
    std::mt19937 random(seed);
    for (int r = 0; r < 112; ++r) {
      Column column;
      for (Index g = 0; g < 128; ++g) if (random() % 4 == 0) column.push_back(g);
      input.relations.push_back(std::move(column));
      input.relation_grades.push_back({0, 0});
    }
    return {std::string(name), std::move(input), small_grid(), 64,
      [](std::size_t i) -> Grade { return {i / 128.0, i / 128.0}; }, seed};
  }
  if (name == "distinct_regions") {
    // Each of the 64 translations visits four different active-data sets.
    Presentation input{1, {}, {}, {}};
    for (Index g = 0; g < 256; ++g) {
      input.generator_grades.push_back({double(g)});
      input.relation_grades.push_back({double(g + 2)});
      input.relations.push_back({g});
    }
    return {std::string(name), std::move(input), chain(4, 1), 64,
      [](std::size_t i) -> Grade { return {double(4 * i)}; }, {}};
  }
  if (name == "free_chain") {
    return {std::string(name), free_module(64, 1), chain(32, 1), 8,
      [](std::size_t i) -> Grade { return {i / 8.0}; }, {}};
  }
  throw std::invalid_argument("Unknown cache workload: " + std::string(name));
}

inline Workload file_workload(const Options& settings) {
  auto input = read_presentation_file(settings.presentation_file);
  const auto pattern = read_slice_pattern_file(settings.slices_file);
  if (pattern.num_parameters() != input.num_parameters) {
    throw std::invalid_argument("Presentation and slices have different parameter counts");
  }
  const auto dimensions = input.num_parameters;
  if (!settings.step.empty()) {
    Grade step;
    std::istringstream coordinates(settings.step);
    std::string token;
    while (coordinates >> token) {
      std::string_view text(token);
      if (text.front() == '+') {
        text.remove_prefix(1);
        if (text.empty() || text.front() == '+' || text.front() == '-') {
          throw std::invalid_argument("Invalid --step coordinate: " + token);
        }
      }
      double value = 0;
      const auto [end, error] = std::from_chars(text.data(), text.data() + text.size(), value);
      if (error != std::errc{} || end != text.data() + text.size() || !std::isfinite(value)) {
        throw std::invalid_argument("--step coordinates must be finite decimals");
      }
      if (!std::isfinite(value * double(*settings.queries - 1))) {
        throw std::overflow_error("The requested translation sweep exceeds finite coordinates");
      }
      step.push_back(value);
    }
    if (step.size() != dimensions) throw std::invalid_argument("--step has the wrong number of coordinates");
    return {"file", std::move(input), pattern.slices(), *settings.queries,
      [step](std::size_t i) {
        Grade shift = step;
        for (auto& coordinate : shift) coordinate *= double(i);
        return shift;
      }, {}};
  }
  return {"file", std::move(input), pattern.slices(), 1,
    [dimensions](std::size_t) { return Grade(dimensions, 0); }, {}};
}

// Quote paths as CSV fields, including names containing commas or quotes.
inline std::string csv(const std::string& value) {
  std::string result = "\"";
  for (char c : value) { if (c == '"') result += '"'; result += c; }
  return result + '"';
}

inline void write_input_fields(const Workload& workload, const Options& settings) {
  std::size_t nonzeros = 0, points = 0;
  for (const auto& column : workload.presentation.relations) nonzeros += column.size();
  for (const auto& slice : workload.slices) points += slice.size();
  std::cout << workload.name << ',' << csv(settings.presentation_file.empty() ? "generated" : settings.presentation_file)
            << ',' << csv(settings.slices_file) << ',' << csv(settings.step) << ',' << cache_name(settings.cache) << ',';
  if (workload.seed) std::cout << *workload.seed;
  std::cout << ',' << workload.presentation.num_parameters << ',' << workload.presentation.generator_grades.size()
            << ',' << workload.presentation.relations.size() << ',' << nonzeros << ',' << workload.slices.size()
            << ',' << points << ',' << workload.query_period << ',' << query_count(workload, settings);
}

inline constexpr const char* input_columns =
  "workload,presentation,slice_file,shift_step,cache,seed,parameters,generators,relations,nonzeros,slices,points,query_period,queries";

inline void help(const char* program, const std::vector<std::string_view>& names) {
  std::cout << "Usage: " << program << " [WORKLOAD] [--cache reuse|reset] [--queries N]\n"
            << "       [--presentation FILE --slices FILE] [--step \"x y ...\"] [--answers FILE]\n\n"
            << "Workloads: all (default), file";
  for (auto name : names) std::cout << ", " << name;
  std::cout << "\nfile requires both input paths and uses zero translation unless --step is supplied.\n"
            << "For file inputs, --step with --queries generates translations i * step, starting at zero.\n"
            << "--queries repeats the workload's finite query schedule to the requested count.\n"
            << "reuse retains Engine caches; reset clears them before every measured query.\n"
            << "SlicePattern geometry stays prepared in either policy.\n"
            << "--answers streams complete answers in an untimed pass; no file is written by default.\n";
}
}  // namespace benchmark
