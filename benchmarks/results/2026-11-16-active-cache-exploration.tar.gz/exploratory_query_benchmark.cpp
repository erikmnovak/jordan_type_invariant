/** @file query_benchmark.cpp
 * @brief Compare reuse on repeated regions and distinct-region controls.
 *
 * Each workload and query method gets a fresh engine and pattern. A cold batch
 * starts with empty caches; a warm batch repeats it and checks every answer.
 * Run the same driver against both kernels, alternating process order.
 * Optional arguments: an answer-dump path, then an SCC2020 presentation path.
 * Full dumps allow before/after comparison outside the timed region.
 */
#include <jordan/io.hpp>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using namespace jordan::f2;
using Clock = std::chrono::steady_clock;

namespace {
struct Workload {
  std::string name;
  Presentation presentation;
  std::vector<std::vector<Grade>> slices;
  std::vector<Grade> shifts;
};

double milliseconds(Clock::time_point start) {
  return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

// Keep the original cache study's presentation and seed for continuity.
Presentation grid_presentation() {
  std::mt19937 random(20261109);
  Presentation result;
  result.num_parameters = 2;
  for (std::size_t g = 0; g < 256; ++g) {
    result.generator_grades.push_back({double(random() % 12), double(random() % 12)});
  }
  for (std::size_t j = 0; j < 320; ++j) {
    Grade grade(2, 0);
    Column column;
    for (int k = 0; k < 4; ++k) {
      const auto g = static_cast<Index>(random() % 256);
      column.push_back(g);
      for (std::size_t axis = 0; axis < 2; ++axis) {
        grade[axis] = std::max(grade[axis], result.generator_grades[g][axis]);
      }
    }
    for (auto& x : grade) x += double(random() % 4);
    std::sort(column.begin(), column.end());
    Column normalized;
    for (std::size_t k = 0; k < column.size();) {
      std::size_t end = k + 1;
      while (end < column.size() && column[end] == column[k]) ++end;
      if ((end - k) % 2) normalized.push_back(column[k]);
      k = end;
    }
    result.relations.push_back(std::move(normalized));
    result.relation_grades.push_back(std::move(grade));
  }
  return result;
}

std::vector<Workload> synthetic_workloads() {
  const auto presentation = grid_presentation();
  const std::vector<std::vector<Grade>> grid{{{0, 0}}, {{1, 0}, {0, 1}},
    {{2, 0}, {1, 1}, {0, 2}}, {{2, 1}, {1, 2}}, {{2, 2}}};
  std::vector<Workload> result;
  for (bool fractional : {false, true}) {
    Workload workload{fractional ? "fractional_grid" : "integer_grid", presentation, grid, {}};
    for (int repeat = 0; repeat < 3; ++repeat) {
      const double offset = fractional ? repeat / 4.0 : 0.0;
      for (int x = 4; x < 10; ++x) {
        for (int y = 4; y < 10; ++y) workload.shifts.push_back({x + offset, y + offset});
      }
    }
    result.push_back(std::move(workload));
  }

  // Many distinct coordinates, one nontrivial relation space throughout.
  Workload dense{"dense_region", {2, std::vector<Grade>(128, {0, 0}), {}, {}}, grid, {}};
  std::mt19937 random(20261116);
  for (int r = 0; r < 112; ++r) {
    Column column;
    for (Index g = 0; g < 128; ++g) if (random() % 4 == 0) column.push_back(g);
    dense.presentation.relations.push_back(std::move(column));
    dense.presentation.relation_grades.push_back({0, 0});
  }
  for (int i = 0; i < 64; ++i) dense.shifts.push_back({i / 128.0, i / 128.0});
  result.push_back(std::move(dense));

  // Every grade changes active data. Small interval dimensions expose the
  // classification/storage overhead when reductions cannot be shared.
  Workload distinct{"distinct_regions", {1, {}, {}, {}}, {{{0}}, {{1}}, {{2}}, {{3}}}, {}};
  for (Index g = 0; g < 256; ++g) {
    distinct.presentation.generator_grades.push_back({double(g)});
    distinct.presentation.relation_grades.push_back({double(g + 2)});
    distinct.presentation.relations.push_back({g});
  }
  for (int i = 0; i < 64; ++i) distinct.shifts.push_back({double(4 * i)});
  result.push_back(std::move(distinct));

  // A long streaming case with cheap reductions and constant module maps.
  Workload free{"free_chain", {1, std::vector<Grade>(64, {0}), {}, {}}, {}, {}};
  for (int i = 0; i < 32; ++i) free.slices.push_back({{double(i)}});
  for (int i = 0; i < 8; ++i) free.shifts.push_back({i / 8.0});
  result.push_back(std::move(free));
  return result;
}

Workload file_workload(const std::string& path) {
  Workload result{"file_presentation", read_presentation_file(path), {}, {}};
  if (result.presentation.num_parameters != 2 || result.presentation.generator_grades.empty()) {
    throw std::invalid_argument("The optional fixture must have two parameters and generators");
  }
  Grade low = result.presentation.generator_grades.front(), high = low;
  for (const auto* grades : {&result.presentation.generator_grades, &result.presentation.relation_grades}) {
    for (const auto& grade : *grades) {
      for (std::size_t k = 0; k < 2; ++k) {
        low[k] = std::min(low[k], grade[k]);
        high[k] = std::max(high[k], grade[k]);
      }
    }
  }
  Grade step{(high[0] - low[0]) / 16, (high[1] - low[1]) / 16};
  for (double& x : step) if (x == 0) x = 1;
  for (int i = 0; i < 4; ++i) result.slices.push_back({{i * step[0], i * step[1]}});
  for (int x = 0; x < 8; ++x) {
    for (int y = 0; y < 8; ++y) {
      result.shifts.push_back({low[0] + 2 * x * step[0], low[1] + 2 * y * step[1]});
    }
  }
  return result;
}

std::vector<std::size_t> answer(Engine& engine, const SlicePattern& pattern,
                               const Grade& shift, int method) {
  if (method == 2) {
    Grade target = shift;
    for (auto& coordinate : target) coordinate += 0.25;
    return engine.filtered_ranks(pattern, shift, target);
  }
  auto value = engine.jordan_type(pattern, shift,
    method == 0 ? JordanMethod::rank_blocks : JordanMethod::streaming);
  value.power_ranks.insert(value.power_ranks.end(), value.block_multiplicities.begin(),
                          value.block_multiplicities.end());
  return value.power_ranks;
}

void measure(const Workload& workload, int method, std::ofstream& dump) {
  const char* names[]{"rank_blocks", "streaming", "filtered_ranks"};
  const auto prepare = Clock::now();
  Engine engine(workload.presentation);
  SlicePattern pattern(workload.presentation.num_parameters, workload.slices);
  const double prepare_ms = milliseconds(prepare);
  std::vector<std::vector<std::size_t>> expected;
  expected.reserve(workload.shifts.size());
  double first_ms = 0;
  const auto cold = Clock::now();
  for (const auto& shift : workload.shifts) {
    expected.push_back(answer(engine, pattern, shift, method));
    if (expected.size() == 1) first_ms = milliseconds(cold);
  }
  const double cold_ms = milliseconds(cold);
  const auto stats = engine.cache_statistics();
  const auto warm = Clock::now();
  for (std::size_t q = 0; q < workload.shifts.size(); ++q) {
    if (answer(engine, pattern, workload.shifts[q], method) != expected[q]) {
      throw std::logic_error("Cold and warm query results differ");
    }
  }
  const double warm_ms = milliseconds(warm);

  std::uint64_t checksum = 14695981039346656037ULL;
  for (std::size_t q = 0; q < expected.size(); ++q) {
    if (dump.is_open()) dump << workload.name << ',' << names[method] << ',' << q;
    for (auto value : expected[q]) {
      checksum = (checksum ^ value) * 1099511628211ULL;
      if (dump.is_open()) dump << ',' << value;
    }
    if (dump.is_open()) dump << '\n';
  }
  std::size_t points = 0, nonzeros = 0;
  for (const auto& slice : workload.slices) points += slice.size();
  for (const auto& column : workload.presentation.relations) nonzeros += column.size();
  std::cout << workload.name << ',' << names[method] << ',' << workload.presentation.num_parameters << ','
            << workload.presentation.generator_grades.size() << ',' << workload.presentation.relations.size() << ','
            << nonzeros << ',' << workload.slices.size() << ',' << points << ',' << workload.shifts.size() << ','
            << prepare_ms << ',' << first_ms << ',' << cold_ms << ',' << warm_ms << ','
            << stats.cached_grades << ',' << stats.cached_reductions << ','
            << stats.generator_normal_forms << ',' << checksum << '\n';
}
}  // namespace

int main(int argc, char** argv) {
  try {
    if (argc > 3) throw std::invalid_argument("Usage: jordan_benchmark [ANSWER_DUMP [PRESENTATION]]");
    std::ofstream dump;
    if (argc > 1) {
      dump.open(argv[1]);
      if (!dump) throw std::runtime_error("Cannot open answer dump");
    }
    auto workloads = synthetic_workloads();
    if (argc > 2) workloads.push_back(file_workload(argv[2]));
    std::cout << "workload,method,parameters,generators,relations,nonzeros,slices,points,queries,"
                 "prepare_ms,first_ms,cold_batch_ms,warm_batch_ms,cached_grades,cached_reductions,normal_forms,checksum\n"
              << std::fixed << std::setprecision(6);
    for (const auto& workload : workloads) {
      for (int method = 0; method < 3; ++method) measure(workload, method, dump);
    }
    if (dump.is_open()) {
      dump.flush();
      if (!dump) throw std::runtime_error("Could not write answer dump");
    }
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
