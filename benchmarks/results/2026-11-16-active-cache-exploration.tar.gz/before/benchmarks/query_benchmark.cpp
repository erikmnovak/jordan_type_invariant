/** @file query_benchmark.cpp
 * @brief Reproducible timings of grade-cache reuse in repeated exact queries.
 *
 * This compares the same arithmetic and query algorithm with the cache cleared
 * before each query or shared across the batch. Presentation validation and
 * slice-pattern preparation are timed separately. It is not a cross-library
 * benchmark and does not establish a universal speedup.
 */
#include <jordan/jordan.hpp>

#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <random>
#include <vector>

using namespace jordan::f2;
using Clock = std::chrono::steady_clock;

double milliseconds(Clock::time_point start) {
  return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

int main() {
  std::mt19937 random(20261109);
  Presentation presentation;
  presentation.num_parameters = 2;
  constexpr std::size_t generators = 256;
  constexpr std::size_t relations = 320;
  for (std::size_t g = 0; g < generators; ++g) {
    presentation.generator_grades.push_back({double(random() % 12), double(random() % 12)});
  }
  std::size_t nonzeros = 0;
  for (std::size_t j = 0; j < relations; ++j) {
    Grade grade(2, 0);
    Column column;
    for (int k = 0; k < 4; ++k) {
      const auto g = static_cast<Index>(random() % generators);
      column.push_back(g);
      for (std::size_t axis = 0; axis < 2; ++axis) {
        grade[axis] = std::max(grade[axis], presentation.generator_grades[g][axis]);
      }
    }
    for (auto& x : grade) x += double(random() % 4);
    std::sort(column.begin(), column.end());
    // Avoid duplicate entries in this benchmark's reported nonzero count.
    Column normalized;
    for (std::size_t k = 0; k < column.size();) {
      std::size_t end = k + 1;
      while (end < column.size() && column[end] == column[k]) ++end;
      if ((end - k) % 2) normalized.push_back(column[k]);
      k = end;
    }
    nonzeros += normalized.size();
    presentation.relations.push_back(std::move(normalized));
    presentation.relation_grades.push_back(std::move(grade));
  }
  const auto preparation_start = Clock::now();
  Engine engine(presentation);
  SlicePattern pattern(2, {{{0, 0}}, {{1, 0}, {0, 1}}, {{2, 0}, {1, 1}, {0, 2}},
                            {{2, 1}, {1, 2}}, {{2, 2}}});
  const double preparation_ms = milliseconds(preparation_start);
  std::vector<Grade> shifts;
  for (int repeat = 0; repeat < 3; ++repeat) {
    for (int x = 4; x < 10; ++x) for (int y = 4; y < 10; ++y) shifts.push_back({double(x), double(y)});
  }

  std::vector<double> cold_times, shared_times;
  std::size_t checksum = 0;
  CacheStatistics shared_stats;
  for (int repetition = 0; repetition < 5; ++repetition) {
    std::size_t cold_checksum = 0, shared_checksum = 0;
    auto start = Clock::now();
    for (const auto& shift : shifts) {
      engine.clear_cache();
      for (auto count : engine.jordan_type(pattern, shift).power_ranks) cold_checksum += count;
    }
    cold_times.push_back(milliseconds(start));
    engine.clear_cache();
    start = Clock::now();
    for (const auto& shift : shifts) {
      for (auto count : engine.jordan_type(pattern, shift).power_ranks) shared_checksum += count;
    }
    shared_times.push_back(milliseconds(start));
    if (cold_checksum != shared_checksum) return 1;
    checksum = shared_checksum;
    shared_stats = engine.cache_statistics();
  }
  std::sort(cold_times.begin(), cold_times.end());
  std::sort(shared_times.begin(), shared_times.end());
  std::cout << std::fixed << std::setprecision(3)
            << "field=F2 parameters=2 generators=" << generators << " relations=" << relations
            << " nonzeros=" << nonzeros << " slices=5 points=9 queries=" << shifts.size() << '\n'
            << "presentation_and_pattern_ms=" << preparation_ms << '\n'
            << "median_cache_reset_per_query_ms=" << cold_times[2] << '\n'
            << "median_shared_batch_cache_ms=" << shared_times[2] << '\n'
            << "cache_reuse_ratio=" << cold_times[2] / shared_times[2] << '\n'
            << "cached_grades=" << shared_stats.cached_grades
            << " normal_forms=" << shared_stats.generator_normal_forms
            << " checksum=" << checksum << '\n';
}
