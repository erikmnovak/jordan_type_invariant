/** @file method_benchmark.cpp
 * @brief Compare exact Jordan algorithms on deterministic workload families.
 *
 * Each method receives its own engine and pattern. Setup, the first query, and
 * warm batches are timed separately. Full result vectors must agree before
 * timing. Warm batches alternate which method runs first to reduce order bias.
 * These synthetic inputs expose different costs; they are not representative
 * of every research dataset and do not establish a universal speedup.
 */
#include <jordan/jordan.hpp>

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <memory>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using namespace jordan::f2;
using Clock = std::chrono::steady_clock;

namespace {
struct Workload {
  std::string name;
  Presentation presentation;
  std::vector<std::vector<Grade>> slices;
  std::vector<Grade> translations;
};

double elapsed_ms(Clock::time_point start) {
  return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

Presentation free_module(std::size_t count) {
  return {2, std::vector<Grade>(count, Grade{0, 0}), {}, {}};
}

Presentation mixed_module(std::size_t generators, std::size_t relations, std::size_t entries,
                          std::uint32_t seed) {
  std::mt19937 random(seed);
  Presentation result;
  result.num_parameters = 2;
  for (std::size_t g = 0; g < generators; ++g) {
    result.generator_grades.push_back({double(random() % 12), double(random() % 12)});
  }
  for (std::size_t r = 0; r < relations; ++r) {
    Grade grade(2, 0);
    Column raw;
    for (std::size_t j = 0; j < entries; ++j) {
      const auto g = static_cast<Index>(random() % generators);
      raw.push_back(g);
      for (std::size_t axis = 0; axis < 2; ++axis) {
        grade[axis] = std::max(grade[axis], result.generator_grades[g][axis]);
      }
    }
    std::sort(raw.begin(), raw.end());
    Column column;
    for (std::size_t j = 0; j < raw.size();) {
      std::size_t end = j + 1;
      while (end < raw.size() && raw[end] == raw[j]) ++end;
      if ((end - j) % 2) column.push_back(raw[j]);
      j = end;
    }
    for (auto& value : grade) value += double(random() % 4);
    result.relation_grades.push_back(std::move(grade));
    result.relations.push_back(std::move(column));
  }
  return result;
}

std::vector<std::vector<Grade>> chain(std::size_t length) {
  std::vector<std::vector<Grade>> slices;
  for (std::size_t i = 0; i < length; ++i) slices.push_back({{double(i), double(i)}});
  return slices;
}

std::vector<std::vector<Grade>> wide_chain(std::size_t length, std::size_t width) {
  std::vector<std::vector<Grade>> slices(length);
  for (std::size_t l = 0; l < length; ++l) {
    for (std::size_t j = 0; j < width; ++j) {
      slices[l].push_back({double(4 * l + j), double(4 * l + width - 1 - j)});
    }
  }
  return slices;
}

std::uint64_t checksum(const JordanType& type) {
  std::uint64_t sum = 0;
  for (std::size_t i = 0; i < type.power_ranks.size(); ++i) sum += (i + 1) * type.power_ranks[i];
  for (std::size_t i = 0; i < type.block_multiplicities.size(); ++i) {
    sum += (i + 1) * type.block_multiplicities[i];
  }
  return sum;
}

bool same(const JordanType& left, const JordanType& right) {
  return left.power_ranks == right.power_ranks && left.block_multiplicities == right.block_multiplicities;
}

struct Prepared {
  Engine engine;
  SlicePattern pattern;
  explicit Prepared(const Workload& workload)
      : engine(workload.presentation), pattern(workload.presentation.num_parameters, workload.slices) {}
};

double timed_batch(Prepared& prepared, JordanMethod method, const Workload& workload,
                    std::uint64_t expected) {
  const auto start = Clock::now();
  std::uint64_t result = 0;
  for (const auto& shift : workload.translations) {
    result += checksum(prepared.engine.jordan_type(prepared.pattern, shift, method));
  }
  const double time = elapsed_ms(start);
  if (result != expected) throw std::runtime_error("A timed result differs from the verified result");
  return time;
}

void compare(const Workload& workload) {
  auto start = Clock::now();
  Prepared ranked(workload);
  const double rank_setup = elapsed_ms(start);
  start = Clock::now();
  Prepared streamed(workload);
  const double stream_setup = elapsed_ms(start);
  Prepared automatic(workload);

  start = Clock::now();
  const auto rank_first = ranked.engine.jordan_type(ranked.pattern, workload.translations.front(),
                                                   JordanMethod::rank_blocks);
  const double rank_cold = elapsed_ms(start);
  start = Clock::now();
  const auto stream_first = streamed.engine.jordan_type(streamed.pattern, workload.translations.front(),
                                                       JordanMethod::streaming);
  const double stream_cold = elapsed_ms(start);
  start = Clock::now();
  const auto auto_first = automatic.engine.jordan_type(automatic.pattern, workload.translations.front());
  const double auto_cold = elapsed_ms(start);
  if (!same(rank_first, stream_first)) throw std::runtime_error("The methods disagree on the first query");
  if (!same(rank_first, auto_first)) throw std::runtime_error("Automatic selection changes the result");

  // Warm both complete workloads and compare every output coordinate, not only
  // a checksum. Timed repetitions then measure already-prepared query work.
  std::uint64_t expected = 0;
  for (const auto& shift : workload.translations) {
    const auto rank = ranked.engine.jordan_type(ranked.pattern, shift, JordanMethod::rank_blocks);
    const auto stream = streamed.engine.jordan_type(streamed.pattern, shift, JordanMethod::streaming);
    const auto selected = automatic.engine.jordan_type(automatic.pattern, shift);
    if (!same(rank, stream)) throw std::runtime_error("The methods disagree on a warm-up query");
    if (!same(rank, selected)) throw std::runtime_error("Automatic selection changes a warm-up result");
    expected += checksum(rank);
  }
  std::array<std::vector<double>, 3> times;
  std::array<Prepared*, 3> prepared{&ranked, &streamed, &automatic};
  const std::array<JordanMethod, 3> methods{JordanMethod::rank_blocks, JordanMethod::streaming,
                                           JordanMethod::automatic};
  for (int repetition = 0; repetition < 5; ++repetition) {
    for (int offset = 0; offset < 3; ++offset) {
      const auto method = static_cast<std::size_t>((repetition + offset) % 3);
      times[method].push_back(timed_batch(*prepared[method], methods[method], workload, expected));
    }
  }
  for (auto& values : times) std::sort(values.begin(), values.end());
  std::size_t nonzeros = 0, points = 0;
  for (const auto& column : workload.presentation.relations) nonzeros += column.size();
  for (const auto& slice : workload.slices) points += slice.size();
  std::cout << workload.name << ',' << workload.presentation.generator_grades.size() << ','
            << workload.presentation.relations.size() << ',' << nonzeros << ',' << workload.slices.size()
            << ',' << points << ',' << workload.translations.size() << ',' << rank_setup << ','
            << stream_setup << ',' << rank_cold << ',' << stream_cold << ',' << auto_cold << ','
            << times[0][2] << ',' << times[1][2] << ',' << times[2][2] << ','
            << times[0][2] / times[1][2] << ',' << expected << '\n';
  std::cout.flush();
}
}  // namespace

int main() {
  std::vector<Workload> workloads;
  for (std::size_t length : {8, 32, 128, 256}) {
    workloads.push_back({"free_chain_" + std::to_string(length), free_module(64), chain(length), {{0, 0}}});
  }
  Workload short_grid{"short_grid", mixed_module(256, 320, 4, 20261109),
                     {{{0, 0}}, {{1, 0}, {0, 1}}, {{2, 0}, {1, 1}, {0, 2}},
                      {{2, 1}, {1, 2}}, {{2, 2}}}, {}};
  for (int x = 5; x < 8; ++x) for (int y = 5; y < 9; ++y) short_grid.translations.push_back({double(x), double(y)});
  workloads.push_back(std::move(short_grid));
  workloads.push_back({"odd_width_3", free_module(32), wide_chain(32, 3), {{0, 0}}});
  workloads.push_back({"even_width_2", free_module(32), wide_chain(64, 2), {{0, 0}}});
  workloads.push_back({"mixed_chain", mixed_module(128, 96, 4, 44001), chain(64),
                       {{0, 0}, {1, 0}, {0, 1}, {1, 1}}});
  workloads.push_back({"dense_relations", mixed_module(128, 112, 32, 44002), chain(64), {{0, 0}}});

  std::cout << std::fixed << std::setprecision(6)
            << "workload,generators,relations,nonzeros,slices,points,queries,rank_setup_ms,stream_setup_ms,"
               "rank_first_ms,stream_first_ms,auto_first_ms,rank_warm_ms,stream_warm_ms,auto_warm_ms,"
               "warm_ratio,checksum\n";
  for (const auto& workload : workloads) compare(workload);
}
